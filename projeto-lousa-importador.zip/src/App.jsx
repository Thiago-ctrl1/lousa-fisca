import React, { useState } from 'react';
import ImportadorXML from './ImportadorXML.jsx';

export default function App() {
  const [tela, setTela] = useState('menu');

  return (
    <div className="min-h-screen p-6">
      {tela === 'menu' && (
        <div className="space-y-4">
          <h1 className="text-2xl font-bold">Menu Principal</h1>
          <div className="flex gap-4">
            <button className="px-4 py-2 bg-purple-700 text-white rounded">Nova</button>
            <button className="px-4 py-2 bg-gray-700 text-white rounded" onClick={() => setTela('importador')}>Importador de XML</button>
          </div>
        </div>
      )}
      {tela === 'importador' && <ImportadorXML onVoltar={() => setTela('menu')} />}
    </div>
  );
}
